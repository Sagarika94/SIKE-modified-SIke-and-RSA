#ifndef INTERLEAVE_H_
#define INTERLEAVE_H_

#include <stdint.h>

#include "forceinline.h"

uint64_t interleave8(uint64_t x);

#endif /* INTERLEAVE_H_ */
