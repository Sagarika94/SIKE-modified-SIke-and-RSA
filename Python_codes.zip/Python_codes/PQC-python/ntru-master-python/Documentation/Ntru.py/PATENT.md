-This code implements inventions covered by claims of U.S. patents 7,031,468,
-6,298,137, and 6,081,597, owned by Security Innovation, Inc.
-(www.securityinnovation.com).
-In addition, international patents may apply.
+This code implements inventions covered by claims of U.S. patents 6,081,597
+(the basic NTRUEncrypt patent)
and by similar patents in other countries.
+The patents are held by Security Innovation, Inc. (www.securityinnovation.com).
