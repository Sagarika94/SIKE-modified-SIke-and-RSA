import os

NTRU_N   = 701
NTRU_N32 = 704
NTRU_Q   = 8192

NAMESPACE = os.environ.get('NTRU_NAMESPACE', '')
