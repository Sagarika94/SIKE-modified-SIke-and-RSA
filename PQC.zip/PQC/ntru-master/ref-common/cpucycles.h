#ifndef CPUCYCLES_H
#define CPUCYCLES_H

long long cpucycles(void);

#endif
